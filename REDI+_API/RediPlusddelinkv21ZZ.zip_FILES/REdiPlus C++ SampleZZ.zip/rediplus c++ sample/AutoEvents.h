#if !defined(AutoEvents_H__INCLUDED__)
#define AutoEvents_H__INCLUDED__

// AutoEvents.h : header file
//
class CCacheDlgDlg;


/////////////////////////////////////////////////////////////////////////////
// CAutoEvents command target

class CAutoEvents : public CCmdTarget
{
	DECLARE_DYNCREATE(CAutoEvents)

	CAutoEvents();           // protected constructor used by dynamic creation

// Attributes
private:
	DWORD				dwMyCookie;
	LPCONNECTIONPOINT	pMyCP;

public:
	HRESULT UnAdvise();
	HRESULT AdviseSource(IDispatch * pDispatch);
	afx_msg void CacheEvent(long action, long row);
	ICacheControlPtr m_CacheControl;
	COleVariant m_Column;
	CListBox* m_List;
// Operations
public:
	CCacheDlgDlg * m_pCacheDlgPtr;
	void SetCacheDlgPtr(CCacheDlgDlg * ptr);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAutoEvents)
	public:
	virtual void OnFinalRelease();
	//}}AFX_VIRTUAL

// Implementation
//protected:
	virtual ~CAutoEvents();

	// Generated message map functions
	//{{AFX_MSG(CAutoEvents)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	//DECLARE_MESSAGE_MAP()
	// Generated OLE dispatch map functions
	//{{AFX_DISPATCH(CAutoEvents)
	//afx_msg void CacheEvent(long action, long row);
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()
	DECLARE_INTERFACE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
#endif //#if !define(AutoEvents_H__INCLUDED__)