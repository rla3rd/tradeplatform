// AUTOEVENTS.CPP : implementation file
//

#import "c:\program files\slk\redi\primary\redi.tlb" no_namespace

#include "stdafx.h"
#include "cachedlgdlg.h"
#include "AutoEvents.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////
// CAutoEvents

IMPLEMENT_DYNCREATE(CAutoEvents, CCmdTarget)

BEGIN_DISPATCH_MAP(CAutoEvents, CCmdTarget)
	//{{AFX_DISPLATCH_MAP(CAutoEvents)
	DISP_FUNCTION(CAutoEvents, "CacheEvent", CacheEvent, VT_EMPTY, VTS_I4 VTS_I4)
	//}}AFX_DISPATCH_MAP
END_DISPATCH_MAP()

CAutoEvents::CAutoEvents()
{
	EnableAutomation();
	dwMyCookie = 0;
	pMyCP = NULL;
}

CAutoEvents::~CAutoEvents()
{
}


void CAutoEvents::OnFinalRelease()
{
	// When the last reference for an automation object is released
	// OnFinalRelease is called.  The base class will automatically
	// deletes the object.  Add additional cleanup required for your
	// object before calling the base class.

	CCmdTarget::OnFinalRelease();
}

//BEGIN_MESSAGE_MAP(CAutoEvents, CCmdTarget)
	//{{AFX_MSG_MAP(CAutoEvents)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
//END_MESSAGE_MAP()

BEGIN_INTERFACE_MAP(CAutoEvents, CCmdTarget)
	INTERFACE_PART(CAutoEvents, __uuidof(ECacheControlPtr), Dispatch)
END_INTERFACE_MAP()

///////////////////////////////////////////////////////////

HRESULT CAutoEvents::AdviseSource(IDispatch * pDispatch)
{
	LPCONNECTIONPOINTCONTAINER pCPCont = NULL;
	HRESULT hr;

	hr = pDispatch->QueryInterface(IID_IConnectionPointContainer, (void**) &pCPCont);
	if (FAILED(hr))
		return hr;

	hr = pCPCont->FindConnectionPoint(__uuidof(ECacheControlPtr),&pMyCP);
	pCPCont->Release();
	if(FAILED(hr))
		return hr;

	return pMyCP->Advise(GetIDispatch(TRUE),&dwMyCookie);
}

HRESULT CAutoEvents::UnAdvise()
{
	if(pMyCP)
	{
		pMyCP->Unadvise(dwMyCookie);
		pMyCP->Release();
	}
	return S_OK;
}

void CAutoEvents::SetCacheDlgPtr(CCacheDlgDlg *ptr)
{
	m_pCacheDlgPtr = ptr;
}


//////////////////////////////////////////////////////////////
// Message Handler
void CAutoEvents::CacheEvent(long action, long row) 
{
	COleVariant myvalue, myerr;
	VARIANT rows;
	CString message;
	CString celldata;
	rows.vt = VT_I4;

	if (action == 1)  // query submit event
	{
		for ( int i=0; i<row; ++i)	// row returned is # of rows
		{							// loop thru all to get data
			rows.lVal = i;			// get cells needed
			m_CacheControl->GetCell(rows, m_Column, myvalue, myerr);
		    celldata = myvalue.bstrVal;
			message.Format("%d - %d : %s",action,i,celldata);
			m_List->AddString(message);
		}
	}
	else		// specific coding required for varius action types
	{
		rows.lVal = row;
		m_CacheControl->GetCell(rows,m_Column,myvalue,myerr);	
		celldata = myvalue.bstrVal;
		message.Format("%d - %d : %s",action,row,celldata);
		m_List->AddString(message);
	}
}
