//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CacheDlg.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDS_ABOUTBOX                    101
#define IDD_CACHEDLG_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDI_ICON1                       132
#define IDC_EDIT_CACHE_USERID           1000
#define IDC_EDIT_CACHE_PASSWORD         1001
#define IDC_COMBO_CACHE_TABLE           1002
#define IDC_EDIT_CACHE_WHERE            1003
#define IDC_EDIT_CACHE_COLUMN           1004
#define IDC_RADIO_CACHE_NAME            1005
#define IDC_RADIO_CACHE_NUMBER          1006
#define IDC_BUTTON_CACHE_MESSAGE        1007
#define IDC_LIST_CACHE_MESSAGE          1008
#define IDC_EDIT_CACHE_SEND_USERID      1009
#define IDC_EDIT_CACHE_SEND_MESSAGE     1010
#define IDC_BUTTON_SEND_MESSAGE         1011
#define IDC_BUTTON_SUBMIT_ORDER         1012
#define IDC_COMBO_ORDER_SIDE            1013
#define IDC_EDIT_ORDER_SYMBOL           1014
#define IDC_COMBO_ORDER_EXCHANGE        1015
#define IDC_EDIT_ORDER_QUANTITY         1016
#define IDC_EDIT_ORDER_PRICE            1017
#define IDC_COMBO_ORDER_PRICETYPE       1018
#define IDC_EDIT_ORDER_STOPPRICE        1019
#define IDC_COMBO_ORDER_TIF             1020
#define IDC_EDIT_ORDER_ACCOUNT          1021
#define IDC_EDIT_ORDER_MEMO             1022
#define IDC_BUTTON_SHOW_ORDER           1023
#define IDC_DISPLAY_QUANTITY            1024

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1025
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
