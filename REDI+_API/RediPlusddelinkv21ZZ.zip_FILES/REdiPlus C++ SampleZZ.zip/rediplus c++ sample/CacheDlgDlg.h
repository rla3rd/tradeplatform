// CacheDlgDlg.h : header file
//

#if !defined(AFX_CACHEDLGDLG_H__FF0E3EBA_DB7F_11D0_801C_00805F293310__INCLUDED_)
#define AFX_CACHEDLGDLG_H__FF0E3EBA_DB7F_11D0_801C_00805F293310__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include <initguid.h>
#include "AutoEvents.h"
#include "CacheDlg.h"

//class CCacheDlgDlgAutoProxy;

/////////////////////////////////////////////////////////////////////////////
// CCacheDlgDlg dialog

class CCacheDlgDlg : public CDialog
{
	DECLARE_DYNAMIC(CCacheDlgDlg);
	//friend class CCacheDlgDlgAutoProxy;

// Construction
public:
	CCacheDlgDlg(CWnd* pParent = NULL);	// standard constructor
	virtual ~CCacheDlgDlg();

// Dialog Data
	//{{AFX_DATA(CCacheDlgDlg)
	enum { IDD = IDD_CACHEDLG_DIALOG };
	CString	m_TableName;
	CString	m_ColumnName;
	CString	m_Password;
	CString	m_UserID;
	CString	m_Where;
	CString	m_SendUserID;
	CString	m_SendMessage;
	CString	m_Account;
	CString	m_Memo;
	CString	m_Price;
	CString	m_Quantity;
	CString	m_StopPrice;
	CString	m_Symbol;
	CString	m_Exchange;
	CString	m_PriceType;
	CString	m_Side;
	CString	m_TIF;
	CString	m_Display_Quantity;
	//}}AFX_DATA

	ICacheControlPtr m_CacheControl;
	CAutoEvents m_pCacheEvt;
	BOOL m_Query;
	COleVariant m_varError;
	CListBox* m_List;

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCacheDlgDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	HICON m_hIcon;

	BOOL CanExit();

	// Generated message map functions
	//{{AFX_MSG(CCacheDlgDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnClose();
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnButtonCacheMessage();
	afx_msg void OnButtonSendMessage();
	afx_msg void OnButtonSubmitOrder();
	afx_msg void OnButtonShowOrder();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CACHEDLGDLG_H__FF0E3EBA_DB7F_11D0_801C_00805F293310__INCLUDED_)
